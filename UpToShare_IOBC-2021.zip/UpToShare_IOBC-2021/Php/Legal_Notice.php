<html lang="fr">
<head>
    <title>UpToShare</title>
    <meta charset="UTF-8">
    <meta name="description" content="A cross-generational plateform for sharing skills and experience">
    <meta name="keywords" content="Html, Css, Php">
    <meta name="author" content="Do Duy Dao, Sofiane, Ilias, Ted, Jade, TaAnhQuan">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="../CSS/Main.css">
    <link rel="stylesheet" href="../CSS/Legal-Notice.css">
    <link rel="shortcut icon" href="../Img/UpToShare_logo.png" type="image/x-icon">
</head>

<body id="background">
<header>
    <div class="nav">
        <div class="name">
            <div>
                <img src="../Img/UpToShare_logo.png" alt="UpToShare" width="15%" style="margin-left: 5%">
                <label>
                    <input type="text" placeholder="Search.." class="search" style="margin-left: 30%;">
                </label>
            </div>
            <script>
                function ouvrirPage() {
                    var a = document.getElementById("search").value;

                    if (a === "page 1") {
                        window.open("/inscription.html");
                    }

                    if (a === "page 2") {
                        window.open("/connexion.html");
                    }
                }
            </script>
            <div class="lang-menu" style="margin-left: 23%;margin-top: 2.5%;font-family: fantasy;width: 100%">
                <div class="selected-lang" style="color: #EF7F00">
                    English
                </div>
                <ul>
                    <li>
                        <a href="" class="en">English</a>
                    </li>
                    <li>
                        <a href="" class="fr">French</a>
                    </li>
                    <li>
                        <a href="" class="ar">Arabic</a>
                    </li>
                </ul>
            </div>
        </div>

        <nav class="menu">
            <ul>
                <li><a href="index.php"><img src="../Img/house%20(1).png" alt="House" style="width: 30%"></a></li>
                <li><a href="News-Posts.php"><img src="../Img/news.png" alt="News" style="width: 30%" id="international"></a></li>
                <li><a href="live.php"><img src="../Img/blog%20(1).png" alt="videos/live" style="width: 30%"></a></li>
            </ul>
            <p style="width: 10%; margin-top: 4%; font-family: fantasy; font-size: 14pt" id="signup"><a href="" style="text-decoration: none; width: 8%; letter-spacing:1pt" class="signup">Sign Up</a></p>
            <p style="width: 10%; margin-top: 4%; color: #EF7F00; font-family: fantasy; font-size: 14pt" class="signin"><a href="" style="text-decoration: none; letter-spacing:1pt" class="signin">Sign In</a></p>
        </nav>
    </div>
</header>

<div style="margin-left: 2%; width: 95%">
    <h2 style="font-family: Lato, sans-serif; font-size: 40pt;color: #EF7F00">Legal Notice</h2>
    <div class="container2">
        <p class="espacement"><strong>Law No. 78-17 of January 6, 1978</strong> relating to information technology, files and freedoms:
            Effective as of 08/12/2020
            In accordance with the provisions of Articles 6-III and 19 of Law No. 2004-575 of June 21, 2004 for Confidence in the Digital Economy, known as the L.C.E.N., Users of the site <strong>https://agenceonmyway.go.yn.fr/</strong> are informed of the present legal notice.
            <br>The connection and navigation on the site (indicate the name of the site) by the User implies full and unreserved acceptance of these legal notices.
            The latter are accessible on the site under the heading <strong>"Legal Notices"</strong>.
        </p>
    </div>

    <div class="container2">
        <div class="encadre"><h2 style="color: #FFFFFF" class="pos-legal">ARTICLE 1 : The publisher</h2></div>
        <p class="espacement">The edition and the direction of the publication of the site <strong>https://agenceonmyway.go.yn.fr/</strong> is assured by <strong>Do Duy Dao, TaAnhQuan, Jade Rahmaoui, Ilias Miri Ted Amoussou, Sofiane Hacherez</strong>
        </p>
    </div>

    <div class="container2">
        <div class="encadre"><h2 style="color: #FFFFFF" class="pos-legal2">ARTICLE 2 : The host</h2></div>
        <p class="typo_leg">The host of the https://agenceonmyway.go.yn.fr/ website is the Company <strong>Planethoster</strong>, whose head office is located at 4416 Louis B. Mayer H7P 0G1 Laval Canada , with the phone number: +1 5148021644.</p>
    </div>

    <div class="container2">
        <div class="encadre"><h2 style="color: #FFFFFF" class="pos-legal2"></h2></div>
        <p class="espacement">The site is accessible by any place, 7 days a week, 24 hours a day except in case of force majeure, scheduled or unscheduled interruption and which may result from a need for maintenance.
            In case of modification, interruption or suspension of the services the site https://agenceonmyway.go.yn.fr/ could not be held responsible.
        </p>
    </div>

    <div class="container2">
        <div class="encadre2"><h2 style="color: #FFFFFF" class="pos-legal">ARTICLE 4 : Data collection</h2></div>
        <p class="espacement">The site is exempt from declaration to the <strong>Commission Nationale Informatique et Libertés</strong> (CNIL) insofar as it does not collect any data concerning users.
        </p>
    </div>

    <div class="container2">
        <div class="encadre"><h2  style="color: #FFFFFF" class="pos-legal2">ARTICLE 5 : Cookies</h2></div>
        <p class="espacement">The User is informed that during his visits to the site, a cookie may be automatically installed on his browser.
            By browsing the site, they accept them.
            A cookie is an element that does not allow the User to be identified but is used to record information relating to the User's navigation on the website. The User may deactivate this cookie by using the parameters in his or her browser software.
        </p>
    </div>

    <div class="container2">
        <div class="encadre2"><h2 style="color: #FFFFFF" class="pos-legal">ARTICLE 6 : Intellectual Property</h2></div>
        <p class="espacement">Any use, reproduction, distribution, marketing, modification of all or part of the site https://agenceonmyway.go.yn.fr/, without permission of the Editor is prohibited and may result in actions and legal proceedings as provided for in particular by the Code of Intellectual Property and the Civil Code.
        </p>
    </div>
</div>

<footer>
    <div>
        <nav>
            <div class="wrapper">
                <h1 style="font-family: Roboto, sans-serif">Up to Share<span class="orange">.</span></h1>
            </div>
            <div class="lien" style="margin-top: 2%">
                <a href="Legal_Notice.php" class="legal" style="font-family: fantasy; text-decoration: none; font-size: 14pt; letter-spacing:1pt">Legal Notice</a>
                <a href="#" class="terms" style="font-family: fantasy; text-decoration: none; font-size: 14pt; letter-spacing:1pt">Terms of Service</a>
                <a href="#" class="about" style="font-family: fantasy; text-decoration: none; font-size: 14pt; letter-spacing:1pt">About Us</a>
                <a href="GDPR.php" class="forms" style="font-family: fantasy; text-decoration: none; font-size: 14pt; letter-spacing:1pt">GDPR</a>
                <a href="#" class="contact" style="font-family: fantasy; text-decoration: none; font-size: 14pt; letter-spacing:1pt">Contact Us</a>
                <a href="#" class="privacy" style="font-family: fantasy; text-decoration: none; font-size: 14pt; letter-spacing:1pt">Privacy Policy</a>
            </div>
        </nav>
    </div>
</footer>
</body>
</html>

<?php
