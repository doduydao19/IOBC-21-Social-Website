<html lang="fr">
<head>
    <title>UpToShare</title>
    <meta charset="UTF-8">
    <meta name="description" content="A cross-generational plateform for sharing skills and experience">
    <meta name="keywords" content="Html, Css, Php">
    <meta name="author" content="Do Duy Dao, Sofiane, Ilias, Ted, Jade, TaAnhQuan">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="../CSS/Main.css">
    <link rel="stylesheet" href="../CSS/GDPR.css">
    <link rel="stylesheet" href="../Js/Menu.js">
    <link rel="shortcut icon" href="../Img/UpToShare_logo.png" type="image/x-icon">
</head>

<body id="background">
<header>
    <div class="nav" id="haut">
        <div class="name">
            <div>
                <img src="../Img/UpToShare_logo.png" alt="UpToShare" width="15%" style="margin-left: 5%">
                <label>
                    <input type="text" placeholder="Search.." class="search" style="margin-left: 30%;">
                </label>
            </div>
            <script>
                function ouvrirPage() {
                    var a = document.getElementById("search").value;

                    if (a === "page 1") {
                        window.open("/inscription.html");
                    }

                    if (a === "page 2") {
                        window.open("/connexion.html");
                    }
                }
            </script>
            <div class="lang-menu" style="margin-left: 23%;margin-top: 2.5%;font-family: fantasy;width: 100%">
                <div class="selected-lang" style="color: #EF7F00">
                    English
                </div>
                <ul>
                    <li>
                        <a href="" class="en">English</a>
                    </li>
                    <li>
                        <a href="" class="fr">French</a>
                    </li>
                    <li>
                        <a href="" class="ar">Arabic</a>
                    </li>
                </ul>
            </div>
        </div>

        <nav class="menu">
            <ul>
                <li><a href="index.php"><img src="../Img/house%20(1).png" alt="House" style="width: 30%"></a></li>
                <li><a href="News-Posts.php"><img src="../Img/news.png" alt="News" style="width: 30%" id="international"></a></li>
                <li><a href="live.php"><img src="../Img/blog%20(1).png" alt="videos/live" style="width: 30%"></a></li>
            </ul>
            <p style="width: 10%; margin-top: 4%; font-family: fantasy; font-size: 14pt" id="signup"><a href="" style="text-decoration: none; width: 8%; letter-spacing:1pt" class="signup">SIGN UP</a></p>
            <p style="width: 10%; margin-top: 4%; color: #EF7F00; font-family: fantasy; font-size: 14pt" class="signin"><a href="" style="text-decoration: none; letter-spacing:1pt" class="signin">SIGN IN</a></p>
        </nav>
    </div>
</header>

<div style="margin-left: 2%; width: 95%">
    <h2 style="font-size: 40pt;color: #EF7F00; font-family: Lato, sans-serif">General Data Protection Regulation</h2>

    <p class="regle">The General Data Protection Regulation (GDPR) is a law in the European Union that governs how companies can use personal information, as of 25 May 2018. If you live in the European Economic Area (EEA), the GDPR gives you specific rights relating to your personal information.</p>

    <div style="margin-bottom: 3.5%"><img src="../Img/fast-forward.png" alt="fast-forward" style="width: 3%"><p class="points">The right to access your personal information. Much of the information that we store about our members is easily accessible by logging into your account in a browser and clicking on the Account option.</p></div>

    <div style="margin-bottom: 3%"><img src="../Img/fast-forward.png" alt="fast-forward" style="width: 3%"><p class="points">The right to update (“rectify”) your personal information. As noted above, much of the information that we store about our members is easily accessible by logging into your account in a browser and clicking on the Account option.</p></div>

    <div style="margin-bottom: 3.5%"><img src="../Img/fast-forward.png" alt="fast-forward" style="width: 3%"><p class="points">There are certain circumstances where you have the right to have your personal information deleted (“erased”) or otherwise removed from UpToShare systems.</p></div>

    <div style="margin-bottom: 3.5%"><img src="../Img/fast-forward.png" alt="fast-forward" style="width: 3%"><p class="points">There are certain circumstances where you have the right to object to, stop, or “restrict” processing of your personal information. This includes withdrawing your consent, where that is the basis on which we process your personal information.</p></div>

    <div style="margin-bottom: 3.5%"><img src="../Img/fast-forward.png" alt="fast-forward" style="width: 3%"><p class="points">You have the right to request a copy of your personal information.</p></div>

    <div style="margin-bottom: 3%"><img src="../Img/fast-forward.png" alt="fast-forward" style="width: 3%"><p class="points">You have the right to complain to a data protection authority about our collection and use of your personal information.</p></div>

    <div style="margin-top: 3.5%"><img src="../Img/fast-forward.png" alt="right-arrow" style="width: 3%"><p class="points">To make requests, or if you have any other question regarding our privacy practices, please contact our Data Protection Officer/Privacy Office at privacy@netflix.com. We respond to all requests we receive from individuals wishing to exercise their data protection rights in accordance with applicable data protection laws.</p></div>
</div>

<div><a id="cRetour" class="cInvisible" href="#haut"></a></div>

<footer>
    <div>
        <nav>
            <div class="wrapper">
                <h1 style="font-family: Roboto, sans-serif">Up to Share<span class="orange">.</span></h1>
            </div>
            <div class="lien" style="margin-top: 2%">
                <a href="Legal_Notice.php" class="legal" style="font-family: fantasy; text-decoration: none; font-size: 14pt; letter-spacing:1pt">Legal Notice</a>
                <a href="#" class="terms" style="font-family: fantasy; text-decoration: none; font-size: 14pt; letter-spacing:1pt">Terms of Service</a>
                <a href="GDPR.php" class="forms" style="font-family: fantasy; text-decoration: none; font-size: 14pt; letter-spacing:1pt">GDPR</a>
                <a href="#" class="privacy" style="font-family: fantasy; text-decoration: none; font-size: 14pt; letter-spacing:1pt">Privacy Policy</a>
                <a href="#" class="contact" style="font-family: fantasy; text-decoration: none; font-size: 14pt; letter-spacing:1pt">Contact Us</a>
                <a href="#" class="about" style="font-family: fantasy; text-decoration: none; font-size: 14pt; letter-spacing:1pt">About Us</a>
            </div>
        </nav>
    </div>
</footer>
</body>
</html>

<?php